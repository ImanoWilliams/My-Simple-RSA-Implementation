
package org.me.RSA;

import java.applet.Applet;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

/*
 * RSA_Simulator.java *
 * Author: Imano Williams
 * Course: COMP620 and Section: 001 
 * Date: November 9, 2014
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("RSA Simulator");
    frame.setSize(500, 570);

    final RSA_Simulator applet = new RSA_Simulator();

    frame.getContentPane().add(applet);
    frame.addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent we) {
            applet.stop();
            applet.destroy();
            System.exit(0);
        }
    });

    frame.setVisible(true);
    applet.init();
    applet.start();
        // TODO code application logic here
    }
    
}
